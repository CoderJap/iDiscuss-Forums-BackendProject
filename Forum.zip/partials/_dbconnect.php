<?php
//Script to connect to database 
$servername="localhost";
$username="root";
$password="";
$database="idiscuss";
$con = mysqli_connect($servername, $username, $password, $database);
// if($con){
//     echo "success";
// }
 ?>